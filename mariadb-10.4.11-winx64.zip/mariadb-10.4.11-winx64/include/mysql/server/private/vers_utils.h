#ifndef VERS_UTILS_INCLUDED
#define VERS_UTILS_INCLUDED

#include "table.h"
#include "sql_class.h"
#include "vers_string.h"

#endif // VERS_UTILS_INCLUDED
